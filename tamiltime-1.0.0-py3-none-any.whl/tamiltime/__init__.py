# __init__.py

from .tamiltime import TamilTime

