# utils.py
# Utility functions for the tamclock library

def utility_function():
    print("This is a utility function!")
