#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import time
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtWidgets import QApplication, QMainWindow, QTextEdit, QVBoxLayout, QWidget, QStatusBar, QLabel


class TamilTime:
    WEEKDAYS = {0: "திங்கள்" ,1:  "செவ்வாய்", 2: 'புதன்', 3: 'வியாழன்', 4: 'வெள்ளி',
        5: 'சனிக்கிழமை', 6: 'ஞாயிறு' }
    MONTHS = {
        1: "தை", 2: "மாசி", 3: "பங்குனி", 4: "சித்திரை",
        5: "வைகாசி", 6: "ஆனி", 7: "ஆடி", 8: "ஆவணி",
        9: "புரட்டாசி", 10: "ஐப்பசி", 11: "கார்த்திகை", 12: "மார்கழி"
    }

    HOUR_PREFIXES = [
        ("நள்ளிரவு", 3), ("அதிகாலை", 6), ("காலை", 12),
        ("மத்தியானம்", 15), ("மாலை", 19), ("இரவு", 23)
    ]

    @staticmethod
    def get_hour_prefix(hour):
        for prefix, end_hour in TamilTime.HOUR_PREFIXES:
            if hour <= end_hour:
                return prefix
        return "நள்ளிரவு"

    @staticmethod
    def get_time():
        local_time = time.localtime()
        hour, minute, second = local_time.tm_hour, local_time.tm_min, local_time.tm_sec
        day, month, year, week_day = local_time.tm_mday, local_time.tm_mon, local_time.tm_year, local_time.tm_wday

        time_str = f"{TamilTime.get_hour_prefix(hour)} {hour}:{minute:02d}:{second:02d}"
        date_str = f"{TamilTime.MONTHS[month]} {day}, {year} - {TamilTime.WEEKDAYS.get(week_day, '')}"
        return f"{time_str} | {date_str}"


